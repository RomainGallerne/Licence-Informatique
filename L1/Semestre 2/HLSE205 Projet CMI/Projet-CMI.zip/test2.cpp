#include <iostream>
bool prenable(int y,int x)
{
  int b,c,d,deca; //b pion ennemi,d dame ennemie,c tu es une dame
  if (Player=1)
  {deca=-1;}
  else{deca=1;}
  if (Damier[y+deca][x+deca]==b || Damier[y+deca][x+deca]==d)
  {
    if (Damier[y+2*deca][x+2*deca]==0)
      {
        return true;
      }
      else if (Damier[y+deca][x-deca]==b || Damier[y+deca][x-deca]==d)
      {
        if (Damier[y+2*deca][x-2*deca]==0)
        {
        return true;
        }
      }
  }









}

int main(){

std::cout << "Pion blanc " << "\u25CF" << std::endl;

std::cout << "Pion noir  " << "\u25CB" << std::endl;

std::cout << "Reine blanche " << "\u265A" << std::endl;

std::cout << "Reine noire   " << "\u2654" << std::endl;

return 0;
}