#include <iostream>
/*void coup(int Matrice[10][10])
do
{
  std::cout<<"donnez une coordonnée du jeton (ligne) "<<std::endl;
  std::cin<<i;
  std::cout<<"donnez une coordonnée du jeton (colonne) "<<std::endl;
  std::cin<<j;
  std::cout<<"donnez une coordonnée de la case où vous voulez aller (ligne) "<<std::endl;
  std::cin<<i2;
  std::cout<<"donnez une coordonnée de la case où vous voulez aller (colonne) "<<std::endl;
  std::cin<<j2;./br
} while ( non(verification(i,j,i2,j2))
    //if (((j2=j+1) ||(j2=j-1) && (i2=i+1)))
    //{Matrice[i2][j2]=Matrice[i][j];
    //Matrice[i][j]=0;
    //il faut aussi faire la fonction qui me dit si je peux prendre le pion ou 2 pions à la suite
    //else std::cout<<"votre coup n'est pas valide! "<<std::endl;

    //fonction prendre (Sauf que du coup pour les Blanc si ils sont en haut du coup ça marche mais pour celui qui est en base ça fonctionne pas par ce que du coup pour lui ça fera i-1) puis que le point (0,0) est en haut à gauche
    // faut aussi un fonction qui dit qui joue pour remplacé à chaque fois celui qui se fait mangé et celui qui mange et qui rend celui qui joue
     if (celui qui joue=NOIR) si c'est Blanc on remplace tout les "NOIR" par des blancs et                          inversement
      if (Damier[i+1][j+1] || Damier[i+1][j-1] = BLANC)
      {on regarde si y'a un pion adverse encore après parce que sinon on peux pas le mangé
      if (Damier[i+2][j+2]=BLANC) {je ne peux pas joué} {else je peux mangé Damier[i+2][j+2]=Damier[i][j]; jetonB=jetonB-1;
      Damier[i][j]='0';}
      if(Damier[i+2][j-2]=BLANC)
      {je peux pas mangé}
      {else je peux mangé 
      Damier[i+2][j-2]=Damier[i][j]; 
      jetonB=jetonB-1;
      Damier[i][j]='0'; }}
      
  //edition des tableaux

  affiche();}*/
  


void PlateauInitiale(int *Damier, int n) {
  int x,y;
  //On met des 0 partout
    for(x=0;x<100;x++){
      *(Damier+x) = 0;
    }
  //On place les pions noirs
  for(y=0;y<40;y+=20){
    for(x=1;x<10;x+=2){
      *(Damier+y+x) = 2;
    }
    for(x=10;x<20;x+=2){
      *(Damier+y+x) = 2;
    }
  }
  //On place les pions blancs
  for(y=60;y<100;y+=20){
    for(x=1;x<10;x+=2){
      *(Damier+y+x) = 1;
    }
    for(x=10;x<20;x+=2){
      *(Damier+y+x) = 1;
    }
  }
}

void Affiche(int *Damier, int n){
  int x,y;
  std::cout << "  A B C D E F G H J I" << std::endl;
  std::cout << "\u250F\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2513" << std::endl;
  for(y=0;y<100;y+=10){
    std::cout << "\u2503 ";
    for(x=0;x<10;x++){
      if(*(Damier+y+x)==1) {std::cout << "\u25CF" << " ";}
      else if(*(Damier+y+x)==2) {std::cout << "\u25CB" << " ";}
      else if(*(Damier+y+x)==3) {std::cout << "\u265A" << " ";}
      else if(*(Damier+y+x)==4) {std::cout << "\u2654" << " ";}
      else {std::cout << "  ";}	

    }
    std::cout<<"\u2503"<<std::endl;
  }
  std::cout << "\u2517\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u251B" << std::endl;
}

int main(){
  int Damier[10][10];
  PlateauInitiale(&Damier[0][0],sizeof(Damier));
  Affiche(&Damier[0][0],sizeof(Damier));
  return 0;
}