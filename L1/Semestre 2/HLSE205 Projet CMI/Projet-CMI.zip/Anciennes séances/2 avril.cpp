#include <iostream>
using namespace std;

//Declaration des fonctions
bool prenable(int *Case);
void update(int n, int *Origine, int *Destination);
void Jeu();
void DeuxiemeCoup(int *Casedeuxieme);
void PlateauInitiale(int *Damier, int n);
void Affiche(int *Damier, int n);

//Déclaration des variables globales
int Damier[10][10];
bool player = 1; //Si player vaut 1, alors c'est le joueur qui joue, sinon c'est l'IA.


bool prenable(int *Case)
{
  //Selon quel joueur joue, on change la valeur des pions
  //a et c représentent les pions alliés, b et d les ennemis
  int a, b, c, d, coef;
  if (player == 1)
  {
    a = 1; b = 2; c = 3; d = 4;
    coef = -1;
  }
  else
  {
    a = 2; b = 1; c = 4; d = 3;
    coef = 1;
  }
  if ( (*Case == a) //La case est un pion
            && ( (*(Case+coef*9) == b) || (*(Case+coef*11) == b) || (*(Case+coef*9) == d) || (*(Case+coef*11) == d) ) //La case a un pion ou une dame ennemi devant elle
            && ( (*(Case+coef*18) == 0) || (*(Case+coef*22) == 0) ) ) //Y a t-il une case libre derrière ?
            {return true;}
            
  else if ( (*Case == c) //La case est une dame
            && ( (*(Case+coef*9) == b) || (*(Case+coef*11) == b) || (*(Case+coef*9) == d) || (*(Case+coef*11) == d) || (*(Case+coef*9) == b) || (*(Case+coef*11) == b) || (*(Case+coef*9) == d) || (*(Case+coef*11) == d) )  //La case a un pion ou une dame ennemi devant elle ou derrire elle
            && (((*(Case+coef*18)) == 0) || (*(Case+coef*22) == 0) || (*(Case+coef*18) == 0) || (*(Case+coef*22) == 0) )) //Y a t-il une case libre derrière ?
            {return true;}
            
  else {return false;}
}


void update(int n, int *Origine, int *Destination)
{
  int coef; //Coefficient relatif au joueur, -1 si c'est le joueur, 1 sinon
  if (n==1)
  {
    *Destination = *Origine;
    *Origine = 0;
    player = !player;
  }

  else if (n==2)
  {
    *Destination = *Origine;
    *Origine = 0;
    int z = ((Origine + Destination)/2.0)
  }
    if (prenable(Destination)) {DeuxiemeCoup(Destination);}
    else {player = !player;}
}


void Jeu()
{
  bool valide = false; //Le coup est-il valide ?
  int x0, y0, x1, y1; //Cordonnés des pions en quesitons
  int b=0, c=0, d=0; //c est la dame alliés, b et d respectivement les pions ennemis et dames ennemis (on a pas besoin du pion allié)

  int decallage; //Le joueur est blanc, il va vers l'avant; l'IA va vers l'arrière
    if (player == 1) {decallage = -1;}
    else {decallage = 1;}

  //Selon quel joueur joue, on change la valeur des pions
    //a et c représentent les pions alliés, b et d les ennemis
    if (player == 1)
      {
        b = 2; c = 3; d = 4;
     }
    else
      {
        b = 1; c = 4; d = 3;
      }

    bool attaque = false; //Le joueur est obligé de prendre ?

    do {

      if (player == 1)
      {
        cout << "Joueur Blanc : " << endl;
        cout << "Entrez les coordonnées du pions que vous voulez déplacer" << endl;
        cin >> y0 >> x0;
        cout<<"Joueur Blanc : " << endl;
        cout << "Entrez les coordonnées de la destionation" << endl;
        cin >> y1 >> x1;
      }
      else
      {
        cout << "Joueur Noir : " << endl;
        cout << "Entrez les coordonnées du pions que vous voulez déplacer" << endl;
        cin >> y0 >> x0;
        cout<<"Joueur Noir : " << endl;
        cout << "Entrez les coordonnées de la destionation" << endl;
        cin >> y1 >> x1;
      }

      if ( (x0>0 || x0<=10) && (y0>0 || y0<=10) && (x1>0 || x1<=10) && (y1>0 || y1<=10) ) 
      //Si les cases entrés existent
      {
        for (int i=0;i<100;i++)
        //On regarde si il y a des pions prenable
        {
          if (prenable((&Damier[0][0])+i))
          {
            attaque = true;
          }
        }
        cout << attaque << endl;
        if (attaque)
        //Si il y a des pions prenable, le joueur est obligé d'en prendre un
        {
          if (prenable(&(Damier[y0][x0])))
          //Si la case séléctionné est effectivement une case qui peut attaquer
          {
            //On considère d'abord la case comme un pion
            if ( ( (Damier[y1][x1]==b) || (Damier[y1][x1]==d) ) && ( ((x1==x0+decallage) && (y1==y0+decallage)) || ((x1==x0-decallage) && (y1==y0+decallage)) ) ) 
            //est ce que les coordonnées sont les mêmes que le pion qu'on veut prendre ?
            {
              if ( ((0 == Damier[y0+2*decallage][x0+2*decallage]) || (0 == Damier[y0+2*decallage][x0-2*decallage]) ) ) //La case de derrière est-elle libre ?
              {
                valide = true;
                update(2,&Damier[y0][x0],&Damier[y1][x1]);
              } 
            } 
            //Sinon on se demande si c'est une dame
            else if ( ( (Damier[y1][x1]==b) || (Damier[y1][x1]==d) ) && ( ((x1==x0-decallage) && (y1==y0-decallage)) || ((x1==x0+decallage) && (y1==y0-decallage)) ) ) 
              {
                if ( (0 == Damier[y0-2*decallage][x0+2*decallage]) || (0 == Damier[y0-2*decallage][x0-2*decallage]) )//La case de derrière est-elle libre ?
                {
                  valide = true;
                  update(2,&Damier[y0][x0],&Damier[y1][x1]);
                }
              } else {cout << "Vous êtes dans l'obligation de prendre un pion" << endl;}
          } else {cout << "Vous êtes dans l'obligation de prendre un pion, le pion entrée ne peut pas prendre" << endl;}
          attaque = false;
        }  
        else{ if (Damier[y1][x1] == 0) //Si on est pas obligé d'attaquer
          {
            //On considère d'abord un pion
            if ( ((x1==x0-decallage) && (y1==y0+decallage)) || ((x1==x0+decallage) && (y1==y0+decallage)) )
              {
                cout << y0 << x0 << Damier[y0][x0];
                update(1,&Damier[y0][x0],&Damier[y1][x1]);
                valide = true;
              }
            //Puis éventuellement comme un dame
            else if ( (Damier[y0][x0] == c) && ( ((x1==x0+decallage) && (y1==y0+decallage)) || ((x1==x0-decallage) && (y1==y0+decallage)) ) )
              {
                update(1,&Damier[y0][x0],&Damier[y1][x1]);
                valide = true;
              }
          } else {cout << "L'action demandée est impossible" << endl;}
        }
      }
      else {cout << "Il semblerait que l'une des cases entrée n'existe pas" << endl;}
    } while(!valide);
}




void DeuxiemeCoup(int *Casedeuxieme)
  {
    bool valide = false; //Le coup est-il valide ?
    int x0=0, y0=0, x1, y1; //Coordonnées des pions en questions
    int b=0, c=0, d=0; //c est la dame alliés, b et d respectivement les pions ennemis et dames ennemis (on a pas besoin du pion allié)

    //On retrouve les cordonnés de la case
    int n = Casedeuxieme - &(Damier[0][0]);
    while(n>10)
    {
      n-=10;
      y0++;
    }
    while(n>0)
    {
      n-=1;
      x0++;
    }

    int decallage; //Le joueur est blanc, il va vers l'avant; l'IA va vers l'arrière
    if (player == 1) {decallage = -1;}
    else {decallage = 1;}

    if (player == 1)
      {
        cout << "Joueur Blanc : " << endl;
        cout << "Poursuivez l'enchainement" << endl;
        cin >> y1 >>  x1;
      }
      else
      {
        //LANCEMENT DE L'IA AVEC LA CASE FORCEE
      }
    do{
    if ( (x1>0 || x1<=10) && (y1>0 || y1<=10) ) 
    //Si les cases entrées existent

      //On considère d'abord la case d'origine comme un pion
      if ( (Damier[y0+decallage][x0+decallage]==b) || (Damier[y0+decallage][x0-decallage]==b) || (Damier[y0 +decallage][x0+decallage]==d) || (Damier[y0+decallage][x0-decallage]==d) )
      {
        if ( ((x1==x0+decallage) && (y1==y0+decallage)) || ((x1==x0-decallage) && (y1==y0+decallage)) )
        //est ce que les coordonnées sont les mêmes que le pion qu'on veut prendre ?
        //si oui ça correspond 
        {
           if ( (0 == Damier[y0+2*decallage][x0+2*decallage]) || (0 == Damier[y0+2*decallage][x0-2*decallage]) )//La case de derrière est-elle libre ?
              {
                valide = true;
                update(2,&Damier[y0][x0],&Damier[y1][x1]);
              }
        }
      
              
      //Sinon on se demande si c'est une dame
      else if ( (Damier[y0][x0] == c) && ( (Damier[y0-decallage][x0-decallage]==b) || (Damier[y0-decallage][x0+decallage]==b) || (Damier[y0-decallage][x0-decallage]==d) || (Damier[y0-decallage][x0+decallage]==d) ) )
        {
          if ( ((x1==x0-decallage) && (y1==y0+decallage)) || ((x1==x0-decallage) && (y1==y0+decallage)) )
          {
            if ( (0 == Damier[y0-2*decallage][x0+2*decallage]) || (0 == Damier[y0-2*decallage][x0-2*decallage]) )//La case de derrière est-elle libre ?
              {
                valide = true;
                update(2,&Damier[y0][x0],&Damier[y1][x1]);
              }
            }
          } else {cout << "Vous êtes dans l'obligation de prendre un pion" << endl;}
      }
    }while(!valide);
}




void PlateauInitiale(int *Damier, int n) 
{
  int x,y;
  //On met des 0 partout
    for(x=0;x<100;x++){
      *(Damier+x) = 0;
    }
  //On place les pions noirs
  for(y=0;y<40;y+=20){
    for(x=1;x<10;x+=2){
      *(Damier+y+x) = 2;
    }
    for(x=10;x<20;x+=2){
      *(Damier+y+x) = 2;
    }
  }
  //On place les pions blancs
  for(y=60;y<100;y+=20){
    for(x=1;x<10;x+=2){
      *(Damier+y+x) = 1;
    }
    for(x=10;x<20;x+=2){
      *(Damier+y+x) = 1;
    }
  }
}


void Affiche(int *Damier, int n)
{
  int x,y;
  cout << "    0 1 2 3 4 5 6 7 8 9" << endl;
  cout << "  \u250F\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2513" << endl;
  for(y=0;y<100;y+=10){
    std::cout << y/10;
    if (y/10 < 10) {cout << " ";}
    std::cout << "\u2503 ";
    for(x=0;x<10;x++){
      if(*(Damier+y+x)==1) {std::cout << "\u25CF" << " ";}
      else if(*(Damier+y+x)==2) {cout << "\u25CB" << " ";}
      else if(*(Damier+y+x)==3) {cout << "\u265A" << " ";}
      else if(*(Damier+y+x)==4) {cout << "\u2654" << " ";}
      else {cout << "  ";}	

    }
    cout << "\u2503" << endl;
  }
  cout << "  \u2517\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u251B" << endl;
}



int main()
{
  int victoire=0;
  int n = sizeof(Damier)/sizeof(int);
  PlateauInitiale(&Damier[0][0],n);
  Affiche(&Damier[0][0],n);
  while(victoire==0)
  {
    Jeu();
    Affiche(&Damier[0][0],n);
  }
  return 0;
}