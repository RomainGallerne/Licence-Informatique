#include <iostream>
using namespace std;

int Damier[10][10];

void Verification(int *(Damier[10][10])){
     //le joueur qui joue est forcement l'humain intelligent RPZ
     bool valide = false;
    { do { int x,x1,y,y1;
        cout<<"Jouer Blanc:donnez les coordonnées du pions que vous voulez bouger"<<std::endl;
        cin>>y>>x;
        cout<<"Jouer Blanc:donnez les coordonnées où vous voulez aller"<<std::endl;
        cin>>y1>>x1;
        if (prenable(&Damier[y][x]))//LE PION PEUT MANGER
          { // CONDITION QUAND C'EST PRENABLE
            if ((*Damier[y][x]!=3)) // si c'est pas une dame (blanche est ce que ça considère noir?) on fait les test pour les pions
          {
            if ((*Damier[y-1][x-1]==2) || (*Damier[y-1][x+1]==2)) //y'a un pion noir en diago
          {
            if ( ((x1==x+2) && (y1==y+2)) || ((x1==x-2)&& (y1==y+2)) ) //est ce que les coordonnées sont les mêmes que le pion qu'on peut prendre?
            {//si oui ça correspond 
              valide = true;
              update(2,&Damier[y][x],&Damier[y1][x1]);
              }
        
            else {cout<<"ton coup n'est pas valide essaie encore"<<std::endl;
            }
         
          }
         
         }
         else {
           if ( (*Damier[y-1][x-1]==2) || (*Damier[y-1][x+1]==2) || *Damier[y+1][x-1]==2 || *Damier[y+1][x+1]==2) //on regarde si y'a un pion noir dans les diago
              {
            if ( ( (x1==x+2) && (y1==y+2) ) || ( (x1==x+2) && (y1==y-2) ) || ( (x1==x-2) && (y1==y+2) )  || ( (x1==x-2) && (y1==y-2) )   ) //est ce que les coordonnées de la dame sont les mêmes que le pion qu'on peut prendre?
            {//si oui ça correspond 
              valide = true;
              update(2,&Damier[y][x],&Damier[y1][x1]);
              }
        
            else {cout<<"ton coup n'est pas valide essaie encore"<<std::endl;} //si tout les pion sont autre que noir alors on peut pas prendre (des pièces blanche)
              }
              }
          }
          //FIN DE CONDITION DE PRENABLE ON FAIT QUE LES DEPLACEMENT DE 1 
          else { //maintenant on fait pour les décallage de 1 1er différent d'une dame blanche c'est à dire qu'il ne peut pas reculé DEPLACEMENT PION BLANC
            if (*Damier[y][x]!=3)         //diago à droite               Diago à gauche  
            {if (((*Damier[y-1][x+1]==1 &&  ((x1=x+1)&& (y1=y-1)))) || (*Damier[y-1][x-1]==1 &&  ((x1=x-1)&& (y1=y-1)))
            {
              cout<<"ton coup n'est pas valide essaie encore"<<std::endl;
            }
            else if (*Damier[y+1][x+1]==0)&& (x1=x+1) && (y1=y+1)){ // si le coup joué est en diagonal c'est bon
            {valide=true;
            update(1,&Damier[y][x],&Damier[y1][x1]);
            }
            else if ((Damier[y+1][x-1]==0)&& (x1=x-1) && (y1=y+1)){ // si le coup joué est en diagonal c'est bon
            {valide=true;
            update(1,&Damier[y][x],&Damier[y1][x1]);}
            

            }

          }
        } // DEPLACEMENT DE LA DAME BLANCHE
        else {{if (((*Damier[y+1][x+1]==1 &&  ((x1=x+1)&& (y1=y+1)))) || (*Damier[y+1][x-1]==1 &&  ((x1=x-1)&& (y1=y+1))) || (*Damier[y-1][x+1]==1 &&  ((x1=x+1)&& (y1=y-1))) || (*Damier[y-1][x-1]==1 &&  ((x1=x-1)&& (y1=y-1))))  //si là où tu veux te déplacé c'est pas bon tu va direct en "pas valide" ça dit true à la condition dans le if sinon avec les ou si y'a a une de bonne ça va dans les else if
        {cout<<"ton coup n'est pas valide essaie encore"<<std::endl;} //SINON TU REGARDES SI TES COORDONNEES CORESPOND AVEC UN ENDROIT SANS PION
            else if ((Damier[y-1][x-1]==0) && (x1=x-1) && (y1=y-1)) //LES CONDITIONS POUR SAVOIR SI LES COORDONNEES CHOISI SONT BIEN DANS UNE CASE VIDE
            {valide=true;
            update(1,&Damier[y][x],&Damier[y1][x1]);}
            else if ((Damier[y-1][x+1]==0) && (x1=x+1) && (y1=y-1))
             {valide=true;
            update(1,&Damier[y][x],&Damier[y1][x1]);}
            else if ((Damier[y-1][x+1]==0) && (x1=x+1) && (y1=y+1))
            {valide=true;
            update(1,&Damier[y][x],&Damier[y1][x1]);}
            else if ((Damier[y-1][x+1]==0) && (x1=x-1) && (y1=y+1))
            {valide=true;
            update(1,&Damier[y][x],&Damier[y1][x1]);}
          }

    }
     } while(!valide); 
     //on initialise tant que c'est vrai on recommence si la condition devient fausse on part du do while donc au départ c'est faux donc si c'est pas valide !valide = vrai et donc on continue si valide= vrai la condition est fausse et on sort de la condition while.
    
    
    
void PlateauInitiale(int *Damier, int n) {
  int x,y;
  //On met des 0 partout
    for(x=0;x<100;x++){
      *(Damier+x) = 0;
    }
  //On place les pions noirs
  for(y=0;y<40;y+=20){
    for(x=1;x<10;x+=2){
      *(Damier+y+x) = 2;
    }
    for(x=10;x<20;x+=2){
      *(Damier+y+x) = 2;
    }
  }
  //On place les pions blancs
  for(y=60;y<100;y+=20){
    for(x=1;x<10;x+=2){
      *(Damier+y+x) = 1;
    }
    for(x=10;x<20;x+=2){
      *(Damier+y+x) = 1;
    }
  }
}

void Affiche(int *Damier, int n)
{
  int x,y;
  cout << "  A B C D E F G H J I" << endl;
  cout << "\u250F\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2513" << endl;
  for(y=0;y<100;y+=10){
    std::cout << "\u2503 ";
    for(x=0;x<10;x++){
      if(*(Damier+y+x)==1) {std::cout << "\u25CF" << " ";}
      else if(*(Damier+y+x)==2) {cout << "\u25CB" << " ";}
      else if(*(Damier+y+x)==3) {cout << "\u265A" << " ";}
      else if(*(Damier+y+x)==4) {cout << "\u2654" << " ";}
      else {cout << "  ";}	

    }
    cout << "\u2503" << endl;
  }
  cout << "\u2517\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u251B" << endl;
}

bool prenable(int *Case)
{
  if ( (Case == 1) //La case a un pion blanc
            && ( (Case-9 == 2) || (Case-11 == 2) || (Case-9 == 4) || (Case-11 == 4) ) //La case a un pion ou une dame noir devant elle
            && ( (Case-18 == 0) || (Case-22 == 0) ) ) //Y a t-il une case libre derrière ?
            {return true;}
            
  else if ( (Case == 3) //La case a une dame blanche
            && ( (Case-9 == 2) || (Case-11 == 2) || (Case-9 == 4) || (Case-11 == 4) || (Case+9 == 2) || (Case+11 == 2) || (Case+9 == 4) || (Case+11 == 4) ) //La case a un pion ou une dame noir devant elle ou derrire elle
            && ( (Case-18 == 0) || (Case-22 == 0) || (Case+18 == 0) || (Case+22 == 0) ) ) //Y a t-il une case libre derrière ?
            {return true;}
            
  else {return false;}
}

void update(int n, int *Origine, int *Destination)
{
  if (n==1)
  {
    Destionation = *Origine;
    Origine = 0;
  }
  if (n==2)
  {
    if (Destionation == Origine - 9)
    {
      Destionation + 9 = Origine;
      Origine = 0;
      Destionation = 0;
    }
    else if (Destination == Origine - 11)
    {
      Destionation + 11 = Origine;
      Origine = 0;
      Destionation = 0;
    }
    if ( prenable(Origine) )
    {
       
    }
  }
}

int main()
{
  PlateauInitiale(&Damier[0][0],sizeof(Damier));
  Affiche(&Damier[0][0],sizeof(Damier));
  Verification(&Damier[x][y]);
  return 0;
}