#include <iostream>


using namespace std;

int Victoire(int *pb,int *pn){
  while (*pn>0 && *pb>0) // tant que y'a encore des jetons des 2 côtés
  {std::cout<<"Tu peux toujours abandonné si tu veux :) "<<std::endl;}
  if (*pb==0) //si y'a plus de pions blanc
{std::cout<<"L'IA a gagné tu es MAUVAIS !! "<<std::endl;
return -1;}
    else if (*pn==0)
      {std::cout<<"Les BLANCS ont gagné tu es trop fort !! "<<std::endl;
      return 1;}//si y'a plus de pion noir

}
int main() {
  char Abandon;
  cin>>Abandon;
  if (Abandon=='a')
  {break;} //sort des boucles
}
  