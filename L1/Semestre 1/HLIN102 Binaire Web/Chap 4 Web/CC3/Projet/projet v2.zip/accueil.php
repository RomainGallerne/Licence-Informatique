<html lang="fr">
	<head>
		<?php include("head.html"); ?>
		<title>Accueil Lotr & Animés</title>
	</head>
	
	<body>
		<?php include("menu.html"); ?>
		
		<h1>Bienvenue!</h1>
		<h2>Sélectionnez votre thème favoris :</h2>
		<div id="mainbox">
			<a id="boxLotR" href="quizLotR.php">
				<p><div class="theme">Thème</div></p>
				<img id="LotR_photo" src="accueil.images/LotR_logo.png" alt="LotR">
			</a>
			<a id="boxJVAnime" href="quizJVA.php">
				<p><div class="theme">Thème</div></p>
				<img id="JVA_photo" src="accueil.images/JVAnime_logo.png" alt="LotR">
			</a>
		</div> <br>
	</body>