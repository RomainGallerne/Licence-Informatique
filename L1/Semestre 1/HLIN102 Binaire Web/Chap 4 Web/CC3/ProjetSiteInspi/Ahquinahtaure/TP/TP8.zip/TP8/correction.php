<!doctype html>
<html lang="fr">

	<head>
		<meta charset="UTF8" />
	</head>

	<body>
	<li> Votre résultat est donc: </li> <br/>
	<?php

		foreach($_GET as $numero=>$reponse){
			echo "<li>" , $numero, " : ", $reponse, "</li>";
		}
	?>
	</body>
</html>